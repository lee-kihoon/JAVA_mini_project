package com.date;

public interface Week {
	public void weekPrint();
}
