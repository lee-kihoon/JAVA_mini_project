package com.product;

public interface Product {
	public String getProduct();
	public int buyProduct(int p_num);
	public int getPrice();
}
